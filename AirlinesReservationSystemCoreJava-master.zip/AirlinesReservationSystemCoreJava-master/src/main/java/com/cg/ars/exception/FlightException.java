package com.cg.ars.exception;

public class FlightException extends Exception
{
	private static final long serialVersionUID = 1763865651349453031L;

	public FlightException(String message)
	{
		super(message);
	}
}
