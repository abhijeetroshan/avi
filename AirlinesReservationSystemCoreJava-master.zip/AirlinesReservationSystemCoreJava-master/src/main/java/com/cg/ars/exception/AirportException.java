package com.cg.ars.exception;

public class AirportException extends Exception
{
	private static final long serialVersionUID = -1971539653817701545L;

	public AirportException(String message)
	{
		super(message);
	}
}
