package com.hotelManagement.exception;

public class HotelException extends RuntimeException {
	

public HotelException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

public HotelException() {
	// TODO Auto-generated constructor stub
}
}
