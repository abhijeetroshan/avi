package com.hotelManagement.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class HotelBooking {

	@Id
	private String bookingNo;
	private String roomId;
	private String userEmailId;
	private String hotelId;
	private String fromDate;
	private String toDate;

	public HotelBooking() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HotelBooking(String bookingNo, String roomId, String userEmailId, String hotelId, String fromDate,
			String toDate) {
		super();
		this.bookingNo = bookingNo;
		this.roomId = roomId;
		this.userEmailId = userEmailId;
		this.hotelId = hotelId;
		this.fromDate = fromDate;
		this.toDate = toDate;
	}

	public String getBookingNo() {
		return bookingNo;
	}

	public void setBookingNo(String bookingNo) {
		this.bookingNo = bookingNo;
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}

	public String getUserEmailId() {
		return userEmailId;
	}

	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getHotelId() {
		return hotelId;
	}

	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}

	@Override
	public String toString() {
		return "HotelBooking [bookingNo=" + bookingNo + ", roomId=" + roomId + ", userEmailId=" + userEmailId
				+ ", hotelId=" + hotelId + ", fromDate=" + fromDate + ", toDate=" + toDate + "]";
	}

}
