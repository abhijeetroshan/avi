package com.hotelManagement.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Hotel")
public class Hotel {
	@Id
	String hotelId;
	String hotelName;
	String state;
	String city;
	String address;
	String phoneNumber;
	String emailId;
	String website;
	String subscriptionDate;
	boolean status;

	public Hotel() {
		super();
	}
	
	

	public Hotel(String hotelId, String hotelName, String state, String city, String address, String phoneNumber,
			String emailId, String website, String subscriptionDate, boolean status) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.state = state;
		this.city = city;
		this.address = address;
		this.phoneNumber = phoneNumber;
		this.emailId = emailId;
		this.website = website;
		this.subscriptionDate = subscriptionDate;
		this.status = status;
	}



	public String getHotelId() {
		return hotelId;
	}

	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getSubscriptionDate() {
		return subscriptionDate;
	}

	public void setSubscriptionDate(String subscriptionDate) {
		this.subscriptionDate = subscriptionDate;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Hotel [hotelId=" + hotelId + ", hotelName=" + hotelName + ", state=" + state + ", city=" + city
				+ ", address=" + address + ", phoneNumber=" + phoneNumber + ", emailId=" + emailId + ", website="
				+ website + ", subscriptionDate=" + subscriptionDate + ", status=" + status + "]";
	}
	
	

}