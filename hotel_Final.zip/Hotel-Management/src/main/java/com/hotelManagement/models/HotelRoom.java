package com.hotelManagement.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "room")
public class HotelRoom {

	@Id
	String roomId;
	int roomNo;
	String hotelId;
	String roomType;
	String roomCategory;
	boolean roomAvailability;

	public HotelRoom() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HotelRoom(String roomId, int roomNo, String hotelId, String roomType, String roomCategory,
			boolean roomAvailability) {
		super();
		this.roomId = roomId;
		this.roomNo = roomNo;
		this.hotelId = hotelId;
		this.roomType = roomType;
		this.roomCategory = roomCategory;
		this.roomAvailability = roomAvailability;
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}

	public int getroomNo() {
		return roomNo;
	}

	public void setroomNo(int roomNo) {
		this.roomNo = roomNo;
	}

	public String getHotelId() {
		return hotelId;
	}

	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public String getRoomCategory() {
		return roomCategory;
	}

	public void setRoomCategory(String roomCategory) {
		this.roomCategory = roomCategory;
	}

	public boolean isRoomAvailability() {
		return roomAvailability;
	}

	public void setRoomAvailability(boolean roomAvailability) {
		this.roomAvailability = roomAvailability;
	}

	@Override
	public String toString() {
		return "HotelRoom [roomId=" + roomId + ", roomNo=" + roomNo + ", hotelId=" + hotelId + ", roomType=" + roomType
				+ ", roomCategory=" + roomCategory + ", roomAvailability=" + roomAvailability + "]";
	}

}
