package com.hotelManagement.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.hotelManagement.models.HotelBooking;

@Repository
public interface HotelBookingRepository extends  MongoRepository<HotelBooking, String>{

}
