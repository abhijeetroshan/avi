package com.hotelManagement.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hotelManagement.models.Admin;
import com.hotelManagement.models.Hotel;
import com.hotelManagement.models.HotelBooking;
import com.hotelManagement.models.HotelRoom;
import com.hotelManagement.models.Manager;
import com.hotelManagement.models.User;
import com.hotelManagement.service.IAdminService;
import com.hotelManagement.service.IHotelService;
import com.hotelManagement.service.IManagerService;
import com.hotelManagement.service.IUserService;

@Controller
public class hotelController {

	@Autowired
	IHotelService hotelService;

	@Autowired
	IAdminService adminService;

	@Autowired
	IManagerService managerService;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	IUserService userService;

	@RequestMapping(value = { "/", "/login" }, method = RequestMethod.GET)
	public String login(@ModelAttribute("admin") Admin admin) {
//		System.out.println("hello.................");
		return "login";
	}

	@RequestMapping("/index")
	public String index(@ModelAttribute("admin") Admin admin, Model m, HttpSession httpSession) {
		System.out.println(admin.toString());
		System.out.println(admin);
		Admin a = adminService.searchById(admin.getUsername());
		// System.out.println("Hiii"+em);
		if (a != null) {
//			System.out.println(admin.getPassword()+a.getPassword());
			if (passwordEncoder.matches(admin.getPassword(), a.getPassword())) {

				httpSession.setAttribute("userId", admin.getUsername());
				if (a.getRole().equalsIgnoreCase("SUPERADMIN"))
					return "SuperAdminMenu";

				if (a.getRole().equalsIgnoreCase("ADMIN"))
					return "hotelMenu";

				if (a.getRole().equalsIgnoreCase("USER")) {
					List<Hotel> hotelList = hotelService.viewHotel();
					m.addAttribute("hotelList", hotelList);

					return "viewHotelForUser";
				}

			} else {
				m.addAttribute("msg", "Wrong Credentials.");
				return "login";
			}

		} else {
			m.addAttribute("msg", "User doesn't Exist.");

		}

		return "login";
	}

	// SUPER ADMIN MENU
	// ADD HOTEL

	@RequestMapping(method = RequestMethod.GET, path = "/addHoteDetails")

	public String addHotel(@ModelAttribute("admin") Admin admin, @ModelAttribute("hotel") Hotel hotel, Model model) {

		return "addHotelform";
	}

	@RequestMapping(method = RequestMethod.POST, path = "/addManagerDetails")

	public String addHotelDetails(@ModelAttribute("hotel") Hotel hotel, @ModelAttribute("manager") Manager manager,
			Model model, HttpSession session) {
		session.setAttribute("hotelId", hotel.getHotelId());
		session.setAttribute("hotel", hotel);
		return "addManagerform";
	}

	@RequestMapping(method = RequestMethod.POST, path = "/setHotelPassword")

	public String addManagerDetails(@ModelAttribute("admin") Admin admin, @ModelAttribute("manager") Manager manager,
			Model model, HttpSession session) {
//       	hotelService.createHotel(hotel);

		manager.setManagerId(session.getAttribute("hotelId").toString());
		session.setAttribute("manager", manager);
		return "setHotelAuthentication";
	}

	@RequestMapping(method = RequestMethod.POST, path = "/AddHotelFinal")

	public String addHotelFinal(@ModelAttribute("admin") Admin admin, Model model, HttpSession session) {
//       	hotelService.createHotel(hotel);
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern, new Locale("ENGLISH", "India"));

		String currDate = simpleDateFormat.format(new Date());
		admin.setPassword(passwordEncoder.encode(admin.getPassword()));
		admin.setUsername(session.getAttribute("hotelId").toString());
		admin.setRole("Admin");
		Hotel hotel1 = (Hotel) session.getAttribute("hotel");
		System.out.println(hotel1);
		if (hotel1.getSubscriptionDate().compareTo(currDate) < 0)
			hotel1.setStatus(true);
		hotel1.setStatus(false);
		System.out.println("after update" + hotel1);
		System.out.println((Hotel) session.getAttribute("hotel"));
		hotelService.createHotel(hotel1);
		Manager manager1 = (Manager) session.getAttribute("manager");
		managerService.createManager(manager1);
		adminService.create(admin);
		model.addAttribute("msg", "Added Successfully!!");
		return "SuperAdminMenu";
	}

	/*
	 * // VIEW HOTEL
	 * 
	 * @RequestMapping(method= RequestMethod.GET,path="/viewHotels") public String
	 * viewHotel(@ModelAttribute("admin")Admin admin,Model model,HttpSession
	 * session) {
	 * 
	 * return "viewHotel"; }
	 * 
	 */
	@RequestMapping(value = "/viewHotel", method = RequestMethod.GET)
	public String getHotel(ModelMap m) {
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern, new Locale("ENGLISH", "India"));

		String currDate = simpleDateFormat.format(new Date());
		
		for (Hotel h : hotelService.viewHotel())
			if(h.getSubscriptionDate().compareTo(currDate) < 0)
				{h.setStatus(false);hotelService.createHotel(h);}
		List<Hotel> hotelList = hotelService.viewHotel();
		m.addAttribute("hotelList", hotelList);
		return "viewHotel";

	}

	// DELETE HOTEL
	@RequestMapping(method = RequestMethod.GET, value = "/deleteHotel")
	public String deleteHotel(@ModelAttribute("hotel") Hotel h, Model m) {

		List<Hotel> hotel = hotelService.viewHotel();
		m.addAttribute("hotelList", hotel);
		System.out.println(hotel);
//		hotelService.deleteByHotelId("nhj");
//		model.addAttribute("Hotel");
		return "deleteHotel";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/delete")
	public String delete(@ModelAttribute("hotel") Hotel hotel) {
		System.out.println(hotel.getHotelId());
		hotelService.deleteByHotelId(hotel.getHotelId());

		return "SuperAdminMenu";
	}

	// RENEW HOTEL SUBSCRIPTION
	@RequestMapping(value = "/renewalHotel", method = RequestMethod.GET)
	public String renewHotel(@ModelAttribute("hotel") Hotel h, Model model) {
		List<Hotel> hotelList = hotelService.viewHotel();
		model.addAttribute("hotelList", hotelList);
		return "renewHotel";
	}

	@RequestMapping(value = "/renewHotelDate")
	public String renewHotelDate(@ModelAttribute("hotel") Hotel h, Model model) {
		System.out.println(h.getHotelId());
		Hotel hotel = hotelService.viewHotelByHotelId(h.getHotelId());
		hotel.setSubscriptionDate(h.getSubscriptionDate());
		hotelService.createHotel(hotel);
		return "SuperAdminMenu";
	}

	// ADMIN MENU
	// ADD HOTEL ROOMS
	@RequestMapping(method = RequestMethod.GET, path = "/addHotelRoom")
	public String addRoom(@ModelAttribute("hotelRoom") HotelRoom hotelroom) {

		return "addHotelRoom";

	}

	@RequestMapping(method = RequestMethod.POST, path = "/hotelRoom")
	public String room(@ModelAttribute("hotelRoom") HotelRoom hotelroom, Model model, HttpSession session) {
		hotelroom.setHotelId(session.getAttribute("userId").toString());
		hotelroom.setRoomAvailability(true);
		hotelroom.setRoomId(hotelroom.getHotelId() + "R" + hotelroom.getroomNo());
		System.out.println(hotelroom.toString());
		hotelService.createHotelRoom(hotelroom);
		// adminService.create(admin);
		model.addAttribute("msg", "Added Successfully!!");

		return "hotelMenu";
	}

	// VIEW HOTEL ROOMS
	@RequestMapping(method = RequestMethod.GET, value = "/viewHotelRoom")
	public String viewRoom(ModelMap m, HttpSession session) {
		List<HotelRoom> roomList = hotelService.viewHotelRoomByhotelId((String) session.getAttribute("userId"));
		m.addAttribute("roomList", roomList);

		return "viewHotelRoom";
	}

	// DELETE HOTEL ROOMS

	@RequestMapping(method = RequestMethod.GET, value = "/deleteHotelRoom")
	public String deleteRoom(@ModelAttribute("room") HotelRoom hotelroom, Model model) {

		List<HotelRoom> hotelroom1 = hotelService.viewHotelRooms();
		model.addAttribute("roomList", hotelroom1);
		return "deleteHotelRoom";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/deleteRoom")
	public String delete(@ModelAttribute("room") HotelRoom hotelroom) {
		System.out.println(hotelroom.getRoomId());
		hotelService.deleteByRoomId(hotelroom.getRoomId());
		return "hotelMenu";
	}

	// update hotel room

	// USER

	// user registration
	@RequestMapping(value = "registerUser", method = RequestMethod.GET)
	public String RegisterUser(@ModelAttribute("user") User user) {
		return "userRegistration";
	}

	@RequestMapping(value = "registerUser/setPass", method = RequestMethod.POST)
	public String RegisterUser1(@ModelAttribute("user") User user, @ModelAttribute("admin") Admin admin,
			HttpSession session) {
		session.setAttribute("roomuser", user);
		return "userpasswordset";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String RegisterUser1(@ModelAttribute("admin") Admin admin, HttpSession session) {

		User user = (User) session.getAttribute("roomuser");
		admin.setUsername(user.getEmail());
		admin.setRole("User");
		userService.create(user);
		Admin admin1 = new Admin(admin.getUsername(), passwordEncoder.encode(admin.getPassword()), admin.getRole());
		adminService.create(admin1);
		return "redirect:/";
	}

	@RequestMapping(value = "/index/{hotelId}")
	public String showAllRoom(@PathVariable("hotelId") String hotelId, ModelMap m) {
		List<HotelRoom> roomList = hotelService.viewHotelRoomByhotelId(hotelId);
		m.addAttribute("roomList", roomList);
		return "viewHotelRoomUser";
	}

	@RequestMapping(value = "/index/{hotelId}/{roomId}")
	public String bookRoom(@PathVariable("hotelId") String hotelId, @PathVariable("roomId") String roomId,
			@ModelAttribute("hotelRoom") HotelRoom hotelRoom, @ModelAttribute("hotelbooking") HotelBooking hotelbooking,
			HttpSession session) {
		HotelRoom room = hotelService.viewHotelRoomByRoomId(roomId);
		hotelRoom.setroomNo(room.getroomNo());
		hotelRoom.setRoomType(room.getRoomType());
		hotelRoom.setRoomCategory(room.getRoomCategory());
		session.setAttribute("hotelId", hotelId);
		session.setAttribute("roomId", roomId);
		return "hotelbookingform";
	}

	@RequestMapping(value = "/bookingfinal", method = RequestMethod.POST)
	public String finalBooking(@ModelAttribute("hotelbooking") HotelBooking hotelbooking, HttpSession session) {
		hotelbooking.setBookingNo("BK" + session.getAttribute("roomId"));
		hotelbooking.setRoomId((String) session.getAttribute("roomId"));
		hotelbooking.setUserEmailId((String) session.getAttribute("userId"));
		hotelbooking.setHotelId((String) session.getAttribute("hotelId"));
		System.out.println(hotelbooking);
		userService.bookingHotelRoom(hotelbooking);
		HotelRoom hotetroom = hotelService.viewHotelRoomByRoomId(hotelbooking.getRoomId());
		hotetroom.setRoomAvailability(false);
		hotelService.createHotelRoom(hotetroom);
//		System.out.println(hotetroom);
		hotetroom.setRoomAvailability(false);
		return "showbooking";

	}

	/*
	 * @RequestMapping(value = "/showbooking") public String
	 * showbooking(@ModelAttribute("admin") Admin admin) {
	 * 
	 * return "showbooking"; }
	 */

}
