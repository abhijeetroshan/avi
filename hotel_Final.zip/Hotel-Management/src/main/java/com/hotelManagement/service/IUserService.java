package com.hotelManagement.service;

import com.hotelManagement.models.HotelBooking;
import com.hotelManagement.models.User;

public interface IUserService {
	public void create(User user);

	public void bookingHotelRoom(HotelBooking hotelbooking);
}
